//
//  ViewController.swift
//  parcialproyecto
//
//  Created by Alexia Ruiz Quiroz on 22/09/21.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    var playerFondo = AVAudioPlayer()
    var playerAnimal = AVAudioPlayer()
    
    let urlFondo = Bundle.main.url(forResource: "fondo", withExtension: "wav")
    let urlGato = Bundle.main.url(forResource: "gato", withExtension: "wav")
    let urlPerro = Bundle.main.url(forResource: "perro", withExtension: "wav")
    let urlVaca = Bundle.main.url(forResource: "vaca", withExtension: "wav")
    
    let gatoBoton = [
        UIImage(named: "gatoboton_00000")!,
        UIImage(named: "gatoboton_00001")!,
        UIImage(named: "gatoboton_00002")!,
        UIImage(named: "gatoboton_00003")!,
        UIImage(named: "gatoboton_00004")!,
        UIImage(named: "gatoboton_00005")!,
        UIImage(named: "gatoboton_00006")!,
        UIImage(named: "gatoboton_00007")!,
        UIImage(named: "gatoboton_00008")!,
        UIImage(named: "gatoboton_00009")!,
        UIImage(named: "gatoboton_00010")!,
        UIImage(named: "gatoboton_00011")!
    ]
    let gatoImagen = [
        UIImage(named: "gatoimagen_00000")!,
        UIImage(named: "gatoimagen_00001")!,
        UIImage(named: "gatoimagen_00002")!,
        UIImage(named: "gatoimagen_00003")!,
        UIImage(named: "gatoimagen_00004")!,
        UIImage(named: "gatoimagen_00005")!,
        UIImage(named: "gatoimagen_00006")!,
        UIImage(named: "gatoimagen_00007")!,
        UIImage(named: "gatoimagen_00008")!,
        UIImage(named: "gatoimagen_00009")!,
        UIImage(named: "gatoimagen_00010")!,
        UIImage(named: "gatoimagen_00011")!
    ]
    let perroBoton = [
        UIImage(named: "perroboton_00000")!,
        UIImage(named: "perroboton_00001")!,
        UIImage(named: "perroboton_00002")!,
        UIImage(named: "perroboton_00003")!,
        UIImage(named: "perroboton_00004")!,
        UIImage(named: "perroboton_00005")!,
        UIImage(named: "perroboton_00006")!,
        UIImage(named: "perroboton_00007")!,
        UIImage(named: "perroboton_00008")!,
        UIImage(named: "perroboton_00009")!,
        UIImage(named: "perroboton_00010")!,
        UIImage(named: "perroboton_00011")!
    ]
    let perroImagen = [
        UIImage(named: "perroimagen_00000")!,
        UIImage(named: "perroimagen_00001")!,
        UIImage(named: "perroimagen_00002")!,
        UIImage(named: "perroimagen_00003")!,
        UIImage(named: "perroimagen_00004")!,
        UIImage(named: "perroimagen_00005")!,
        UIImage(named: "perroimagen_00006")!,
        UIImage(named: "perroimagen_00007")!,
        UIImage(named: "perroimagen_00008")!,
        UIImage(named: "perroimagen_00009")!,
        UIImage(named: "perroimagen_00010")!,
        UIImage(named: "perroimagen_00011")!,
        UIImage(named: "perroimagen_00012")!,
        UIImage(named: "perroimagen_00013")!
    ]
    let vacaBoton = [
        UIImage(named: "vacaboton_00000")!,
        UIImage(named: "vacaboton_00001")!,
        UIImage(named: "vacaboton_00002")!,
        UIImage(named: "vacaboton_00003")!,
        UIImage(named: "vacaboton_00004")!,
        UIImage(named: "vacaboton_00005")!,
        UIImage(named: "vacaboton_00006")!,
        UIImage(named: "vacaboton_00007")!,
        UIImage(named: "vacaboton_00008")!,
        UIImage(named: "vacaboton_00009")!,
        UIImage(named: "vacaboton_00010")!,
        UIImage(named: "vacaboton_00011")!
    ]
    let vacaImagen = [
        UIImage(named: "vacaimagen_00000")!,
        UIImage(named: "vacaimagen_00001")!,
        UIImage(named: "vacaimagen_00002")!,
        UIImage(named: "vacaimagen_00003")!,
        UIImage(named: "vacaimagen_00004")!,
        UIImage(named: "vacaimagen_00005")!,
        UIImage(named: "vacaimagen_00006")!,
        UIImage(named: "vacaimagen_00007")!,
        UIImage(named: "vacaimagen_00008")!,
        UIImage(named: "vacaimagen_00009")!,
        UIImage(named: "vacaimagen_00010")!,
        UIImage(named: "vacaimagen_00011")!
    ]

    @IBOutlet weak var lblAnimal: UILabel!
    
    @IBOutlet weak var imgAnimal: UIImageView!
    @IBOutlet weak var imgGato: UIImageView!
    @IBOutlet weak var imgPerro: UIImageView!
    @IBOutlet weak var imgVaca: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            playerFondo = try AVAudioPlayer(contentsOf: urlFondo!, fileTypeHint: AVFileType.wav.rawValue)
            playerFondo.numberOfLoops = -1
            playerFondo.volume = 0.2
            playerFondo.play()
        } catch let error {
            print(error.localizedDescription)
        }
        
        imgGato.animationImages = gatoBoton
        imgGato.animationDuration = 0.5
        imgGato.startAnimating()
        imgPerro.animationImages = perroBoton
        imgPerro.animationDuration = 0.5
        imgPerro.startAnimating()
        imgVaca.animationImages = vacaBoton
        imgVaca.animationDuration = 0.5
        imgVaca.startAnimating()
    }

    @IBAction func doTapGato(_ sender: Any) {
        lblAnimal.text = "Cat"
        imgAnimal.animationImages = gatoImagen
        imgAnimal.animationDuration = 0.5
        imgAnimal.startAnimating()
        
        do {
            playerAnimal = try AVAudioPlayer(contentsOf: urlGato!, fileTypeHint: AVFileType.wav.rawValue)
            playerAnimal.play()
        } catch let error {
            print(error.localizedDescription)
        }
    }
 
    @IBAction func doTapPerro(_ sender: Any) {
        lblAnimal.text = "Dog"
        imgAnimal.animationImages = perroImagen
        imgAnimal.animationDuration = 0.58
        imgAnimal.startAnimating()
        
        do {
            playerAnimal = try AVAudioPlayer(contentsOf: urlPerro!, fileTypeHint: AVFileType.wav.rawValue)
            playerAnimal.play()
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    @IBAction func doTapVaca(_ sender: Any) {
        lblAnimal.text = "Cow"
        imgAnimal.animationImages = vacaImagen
        imgAnimal.animationDuration = 0.5
        imgAnimal.startAnimating()
        
        do {
            playerAnimal = try AVAudioPlayer(contentsOf: urlVaca!, fileTypeHint: AVFileType.wav.rawValue)
            playerAnimal.play()
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    
}

